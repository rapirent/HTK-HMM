PATH=$PATH:"add your htk path here !!!"
